# task-create



<!-- Auto Generated Below -->


## Events

| Event         | Description | Type                |
| ------------- | ----------- | ------------------- |
| `taskCreated` |             | `CustomEvent<void>` |


## Dependencies

### Used by

 - [task-list](../task-list)

### Graph
```mermaid
graph TD;
  task-list --> task-create
  style task-create fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
